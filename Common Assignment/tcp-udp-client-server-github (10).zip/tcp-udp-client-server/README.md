# TCP and UDP Based Client-Server Communication System

A Python socket-programming project that demonstrates TCP and UDP communication at the Transport Layer. It supports multiple TCP clients and UDP datagram messaging.

## Features

- Client ID and message input
- TCP and UDP protocol selection
- Configurable server IP address
- TCP connection establishment and application response
- UDP connectionless datagram transmission
- Displays communication status and round-trip time
- Server handles multiple TCP clients using threads

## Project Structure

```text
tcp-udp-client-server/
├── server.py
├── client.py
├── README.md
└── .gitignore
```

## Requirements

- Python 3.8 or later
- No external Python packages are required

## How to Run

### 1. Download or clone this repository

```bash
git clone https://github.com/YOUR-USERNAME/tcp-udp-client-server.git
cd tcp-udp-client-server
```

### 2. Start the server

Open a terminal in the project folder:

```bash
python server.py
```

The server listens on:
- TCP port: `5000`
- UDP port: `5001`

Keep this terminal running.

### 3. Start a client

Open another terminal in the same folder:

```bash
python client.py
```

Enter the requested details. For testing on the same computer, use `127.0.0.1` as the server IP.

Example:

```text
Enter Client ID: C1
Enter Server IP [127.0.0.1]: 127.0.0.1
Select Protocol (TCP/UDP): TCP
Enter Message: Hello Server
```

Run the client again and select `UDP` to test UDP communication. You can open additional client terminals to test multiple clients.

## TCP and UDP Notes

- TCP is connection-oriented and provides reliable, ordered byte-stream delivery. TCP acknowledgements and retransmission are handled by the TCP protocol.
- The `ACK` text printed by this project is an application-level response from the server, in addition to TCP's own protocol acknowledgements.
- UDP is connectionless and does not guarantee delivery or ordering. The server's `REPLY` is an application-level response; UDP itself does not provide a built-in acknowledgement.
- The displayed time is the client's approximate round-trip time for sending a message and receiving the server response. It is not a one-way packet transmission time.

## Testing

| Test | Action | Expected result |
|---|---|---|
| TCP message | Send a message using TCP | Server prints message; client receives ACK response |
| UDP message | Send a message using UDP | Server prints datagram; client receives reply |
| Multiple clients | Run several clients | Server handles TCP connections in separate threads |
| Unavailable server | Stop server and run client | Client reports connection error or timeout |

## Network Use

For communication between different computers:
1. Connect both computers to the same network.
2. Find the server computer's local IP address.
3. Enter that IP address in the client.
4. Allow inbound TCP port `5000` and UDP port `5001` through the server computer's firewall if required.

## GitHub Upload

1. Sign in to GitHub and create a new repository named `tcp-udp-client-server`.
2. Extract this ZIP file.
3. Open the repository page and choose **Add file → Upload files**.
4. Upload `server.py`, `client.py`, `README.md` and `.gitignore` (or upload the extracted project contents).
5. Select **Commit changes**.

## References

- Python socket documentation: https://docs.python.org/3/library/socket.html
- TCP specification (RFC 9293): https://www.rfc-editor.org/rfc/rfc9293
- UDP specification (RFC 768): https://www.rfc-editor.org/rfc/rfc768
