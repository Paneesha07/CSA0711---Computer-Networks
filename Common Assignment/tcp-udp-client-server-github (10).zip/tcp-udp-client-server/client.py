"""
TCP and UDP Based Client-Server Communication System
Run: python client.py
"""

import socket
import time

TCP_PORT = 5000
UDP_PORT = 5001
BUFFER_SIZE = 4096
TIMEOUT_SECONDS = 5


def run_tcp_client(server_ip, client_id, message):
    """Connect to the TCP server, send a message and receive its ACK."""
    start_time = time.perf_counter()
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.settimeout(TIMEOUT_SECONDS)

    try:
        client_socket.connect((server_ip, TCP_PORT))
        print("Connection Status: Connected using TCP")

        full_message = f"{client_id}: {message}"
        client_socket.sendall(full_message.encode("utf-8"))

        response = client_socket.recv(BUFFER_SIZE)
        elapsed_ms = (time.perf_counter() - start_time) * 1000

        print("Message Received:", response.decode("utf-8", errors="replace"))
        print("Acknowledgement Status: Received")
        print(f"Round-trip Time: {elapsed_ms:.3f} ms")

    except (OSError, socket.timeout) as error:
        print("TCP communication failed:", error)
    finally:
        client_socket.close()


def run_udp_client(server_ip, client_id, message):
    """Send a UDP datagram and wait for the server's application-level reply."""
    start_time = time.perf_counter()
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client_socket.settimeout(TIMEOUT_SECONDS)

    try:
        full_message = f"{client_id}: {message}"
        client_socket.sendto(
            full_message.encode("utf-8"),
            (server_ip, UDP_PORT)
        )
        print("Connection Status: UDP is connectionless (no setup)")

        response, server_address = client_socket.recvfrom(BUFFER_SIZE)
        elapsed_ms = (time.perf_counter() - start_time) * 1000

        print("Message Received:", response.decode("utf-8", errors="replace"))
        print("Server Address:", server_address)
        print("Application Reply Status: Received")
        print(f"Round-trip Time: {elapsed_ms:.3f} ms")

    except socket.timeout:
        print("No UDP reply received before timeout.")
        print("UDP does not guarantee delivery or provide built-in acknowledgements.")
    except OSError as error:
        print("UDP communication failed:", error)
    finally:
        client_socket.close()


def main():
    print("TCP and UDP Based Client-Server Communication System")
    client_id = input("Enter Client ID: ").strip()
    server_ip = input("Enter Server IP [127.0.0.1]: ").strip() or "127.0.0.1"
    protocol = input("Select Protocol (TCP/UDP): ").strip().upper()
    message = input("Enter Message: ")

    if not client_id or not message:
        print("Client ID and message cannot be empty.")
        return

    if protocol == "TCP":
        run_tcp_client(server_ip, client_id, message)
    elif protocol == "UDP":
        run_udp_client(server_ip, client_id, message)
    else:
        print("Invalid protocol. Please enter TCP or UDP.")


if __name__ == "__main__":
    main()
