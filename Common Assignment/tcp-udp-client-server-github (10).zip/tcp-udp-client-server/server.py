"""
TCP and UDP Based Client-Server Communication System
Run this file first: python server.py
"""

import socket
import threading

HOST = "0.0.0.0"
TCP_PORT = 5000
UDP_PORT = 5001
BUFFER_SIZE = 4096


def handle_tcp_client(connection, address):
    """Receive one TCP message and return an application-level ACK."""
    try:
        data = connection.recv(BUFFER_SIZE)
        if not data:
            return

        message = data.decode("utf-8", errors="replace")
        print(f"[TCP] Client {address}: {message}")

        response = f"ACK: Message received by server - {message}"
        connection.sendall(response.encode("utf-8"))
    except OSError as error:
        print(f"[TCP] Error with {address}: {error}")
    finally:
        connection.close()


def start_tcp_server():
    """Listen for TCP clients and handle each connection in a thread."""
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, TCP_PORT))
    server_socket.listen()

    print(f"[TCP] Server listening on {HOST}:{TCP_PORT}")

    while True:
        connection, address = server_socket.accept()
        print(f"[TCP] Connection from {address}")
        client_thread = threading.Thread(
            target=handle_tcp_client,
            args=(connection, address),
            daemon=True
        )
        client_thread.start()


def start_udp_server():
    """Receive UDP datagrams and send an application-level reply."""
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((HOST, UDP_PORT))

    print(f"[UDP] Server listening on {HOST}:{UDP_PORT}")

    while True:
        data, address = server_socket.recvfrom(BUFFER_SIZE)
        message = data.decode("utf-8", errors="replace")
        print(f"[UDP] Client {address}: {message}")

        # This reply is created by the application; UDP itself has no ACK.
        response = f"REPLY: Message received by server - {message}"
        server_socket.sendto(response.encode("utf-8"), address)


if __name__ == "__main__":
    print("TCP and UDP Client-Server System")
    threading.Thread(target=start_tcp_server, daemon=True).start()

    try:
        start_udp_server()
    except KeyboardInterrupt:
        print("\nServer stopped.")
